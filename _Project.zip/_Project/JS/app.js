let sun = document.querySelector('.sun');
let bird1 = document.querySelector('.bird1');
let bird2 = document.querySelector('.bird2');
let text1 = document.querySelector('.text1');
let text2 = document.querySelector('.text2');
// let header = document.querySelector('.header');
window.addEventListener('scroll', function () {
  let data = window.scrollY;
  sun.style.top = data * 0.6 + 'px';
  bird1.style.top = data * 0.9 + 'px';
  bird1.style.left = data * 0.8 + 'px';
  bird2.style.top = data * 0.9 + 'px';
  bird2.style.right = data * 0.8 + 'px';
  text1.style.top = data * 0.8 + 'px';
  text2.style.top = data * 0.8 + 'px';
  // header.style.bottom = data * 0.5 + 'px';
});

let coverLayer = document.querySelector('.cover-layer');
coverLayer.addEventListener('click', function (e) {
  let body = document.querySelector('body');
  let ballon = document.createElement('span');
  ballon.setAttribute('class', 'ballon')
  let x = e.offsetX;
  let y = e.offsetY;
  // console.log(x+'x');
  // console.log(y+'y');
  let size = Math.random() * 100;
  ballon.style.width = size + 'px';
  ballon.style.height = size + 'px';
  ballon.style.top = 20 + y + 'px';
  ballon.style.left = 20 + x + 'px';
  // ballon.style.marginLeft=200+'px'
  coverLayer.appendChild(ballon);
  setTimeout(function () {
    ballon.remove()
  }, 2000)
});

//header
$(document).ready(function () {
  let screenHeight = $(window).height();
  // console.log(screenHeight);
  $(document).scroll(function () {
    // console.log(screenHeight);
    let currentHeight = $(window).scrollTop();
    console.log(currentHeight);
    if (currentHeight >= screenHeight-100) {
      $('.header').addClass('header-scroll');
    } else {
      $('.header').removeClass('header-scroll');
    }
    setActive('home');
  });
});


//waypoint
var waypoints = $('#places').waypoint(function (direction) {
  if (direction == 'down') {
    $('.header').removeClass('header-scroll');
    $('.header').addClass('places-header');
  }
  else {
    $('.header').addClass('header-scroll');
    $('.header').removeClass('places-header');
  }
}, {
  offset: '10%'
});
var waypoints = $('#beach').waypoint(function (direction) {
  if (direction == 'down') {
    $('.header').addClass('header-scroll');
    $('.header').removeClass('places-header');
  }
  else {
    $('.header').removeClass('header-scroll');
    $('.header').addClass('places-header');
  }
}, {
  offset: '10%'
});
var waypoints = $('#beach2').waypoint(function (direction) {
  if (direction == 'down') {
    $('.header').addClass('header-scroll');
    $('.header').removeClass('places-header');
  }
  else {
    $('.header').removeClass('header-scroll');
    $('.header').addClass('places-header');
  }
}, {
  offset: '10%'
});
var waypoints = $('#card').waypoint(function (direction) {
  if (direction == 'down') {
    $('.header').removeClass('header-scroll');
    $('.header').addClass('places-header');
  }
  else {
    $('.header').addClass('header-scroll');
    $('.header').removeClass('places-header');
  }
}, {
  offset: '10%'
});
var waypoints = $('#contact-up').waypoint(function (direction) {
  if (direction == 'down') {
    $('.header').addClass('header-scroll');
    $('.header').removeClass('places-header');
  }
  else {
    $('.header').removeClass('header-scroll');
    $('.header').addClass('places-header');
  }
}, {
  offset: '10%'
}
);
var waypoints = $('#contact-down').waypoint(function (direction) {
  if (direction == 'down') {
    $('.header').removeClass('header-scroll');
    $('.header').addClass('places-header');
  }
  else {
    $('.header').addClass('header-scroll');
    $('.header').removeClass('places-header');
  }
}, {
  offset: '10%'
}
);
//waypoint
function setActive(current){
  $('.nav-link').removeClass('active');
  $(`.nav-link[href='#${current}']`).addClass('active');
}
function scroll(){
  let currentPosition=$('section[id]');
  // console.log(currentPosition);
  currentPosition.waypoint(function(direction){
    if(direction=='down'){
      let currentsectionId=$(this.element).attr('id');
      // console.log(currentsectionId);
      setActive(currentsectionId)
    }
  }, {
    offset: '150px'
  });
  currentPosition.waypoint(function(direction){
    if(direction=='up'){
      let currentsectionId=$(this.element).attr('id');
      // console.log(currentsectionId);
      setActive(currentsectionId)
    }
  }, {
    offset: '-150px'
  });
}
scroll()

//slick

$('.slider-for').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  fade: true,
  asNavFor: '#beaches',
    responsive: [
    // {
    //   breakpoint: 1024,
    //   settings: {
    //     slidesToShow: 3,
    //     slidesToScroll: 3,
    //     infinite: true,
    //     dots: true
    //   }
    // },
    {
      breakpoint: 800,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    },
      {
        breakpoint: 550,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }},

    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
$('#beaches').slick({
  slidesToShow: 3,
  slidesToScroll: 1,
  asNavFor: '.slider-for',
  dots: true,
  centerMode: true,
  focusOnSelect: true
});
//beaches2
$('#beaches2').slick({
  dots: true,
  infinite: false,
  arrows: false,
  speed: 300,
  slidesToShow: 3,
  slidesToScroll: 3,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});

